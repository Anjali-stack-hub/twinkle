# PocketSmart AI: Your Smart Budget & Recommendation Assistant

A complete college-project-ready Generative AI web application for planning home and party budgets and generating personalized recommendations with Google Gemini.

## Features
- Home Budget Planner: room, total budget, required items, quantities, style/preferences.
- Intelligent item-wise allocation with over-budget detection.
- Party Budget Planner: event, guests, venue, budget and allocation across major expenses.
- Gemini-powered personalized recommendations with price estimates, fit explanations and source/search links.
- Budget Summary dashboard with allocated, remaining and over-budget status.
- JSON-file persistence for saved plans.
- Demo mode when `GEMINI_API_KEY` is not configured, so the project can still be demonstrated offline.
- Responsive HTML/CSS/JavaScript UI.

## Architecture

```text
Browser (HTML/CSS/JS)
        |
        | JSON HTTP requests
        v
Flask REST API
  |       |       |
  |       |       +--> JSON storage (data/budgets.json)
  |       +----------> Budget allocation engine
  +------------------> Gemini service (Google GenAI SDK)
                         |
                         v
                    Gemini structured JSON
```

## Folder structure

```text
pocketsmart_ai/
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── routes.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── allocator.py
│   │   ├── gemini_service.py
│   │   └── storage.py
│   ├── templates/
│   │   └── index.html
│   └── static/
│       ├── app.js
│       └── styles.css
├── data/
│   └── budgets.json
├── docs/
│   └── PROJECT_REPORT.md
├── tests/
│   └── test_app.py
├── .env.example
├── .gitignore
├── requirements.txt
├── run.py
└── README.md
```

## Setup

### 1. Install Python
Python 3.10+ is recommended.

### 2. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Gemini

Copy `.env.example` to `.env` and add your Google Gemini API key:

```env
GEMINI_API_KEY=your_api_key_here
GEMINI_MODEL=gemini-3.8-flash
FLASK_SECRET_KEY=change-this-in-production
```

The application uses the current Google GenAI Python SDK:

```python
from google import genai
client = genai.Client()
response = client.models.generate_content(...)
```

Google documents this SDK and the `generate_content` method in its Gemini API documentation. The app also uses JSON response configuration so recommendation responses can be parsed predictably. See: https://ai.google.dev/gemini-api/docs/get-started and https://ai.google.dev/gemini-api/docs/structured-output

### 5. Run

```bash
python run.py
```

Open `http://127.0.0.1:5000`.

### Demo without an API key
Leave `GEMINI_API_KEY` empty. The app automatically returns deterministic demo recommendations from a small built-in catalog. This is useful for classroom presentations where internet/API access is unavailable.

## API endpoints

- `GET /api/health` — health and Gemini configuration status.
- `POST /api/home-plan` — validate and allocate a home budget.
- `POST /api/party-plan` — validate and allocate a party budget.
- `POST /api/recommendations` — generate Gemini or demo recommendations.
- `GET /api/budgets` — list saved plans.
- `POST /api/budgets` — save a plan.
- `DELETE /api/budgets/<id>` — delete a saved plan.

## Sample test data

Home:

```json
{
  "room_type": "Living Room",
  "budget": 80000,
  "preferences": "Modern, warm colors, easy maintenance",
  "items": [
    {"name": "Sofa", "quantity": 1},
    {"name": "Coffee table", "quantity": 1},
    {"name": "TV unit", "quantity": 1},
    {"name": "Floor lamp", "quantity": 2}
  ]
}
```

Party:

```json
{
  "event_type": "Birthday",
  "guests": 50,
  "budget": 60000,
  "venue": "Community hall",
  "preferences": "Vegetarian buffet, simple elegant decoration"
}
```

## Sample AI output

```json
{
  "summary": "Prioritize the sofa and TV unit because they are the highest-use items while keeping lighting within a controlled share of the budget.",
  "recommendations": [
    {
      "item": "Sofa",
      "product_name": "3-Seater Fabric Sofa",
      "estimated_price": 24000,
      "reason": "Fits the modern preference and leaves room for the remaining living-room items.",
      "style_match": "High",
      "budget_fit": "Within target",
      "source_url": "https://www.google.com/search?q=3-seater+fabric+sofa+India"
    }
  ],
  "tips": [
    "Keep at least 5% unallocated for delivery or installation costs."
  ]
}
```

Prices and links returned by AI are estimates and should be verified before purchase. The app does not execute purchases.

## Testing

```bash
pytest -q
```

## College presentation description

**PocketSmart AI** is a Generative AI-powered budgeting and recommendation assistant. Users enter a home or party requirement, available budget, quantities, and preferences. The Flask backend intelligently allocates the budget, detects overspending, and sends the structured requirements to Google Gemini. Gemini produces personalized recommendations with estimated prices, reasons for selection, and source/search links. A responsive dashboard shows the plan, remaining budget, warnings, and saved plans. The project demonstrates Generative AI integration, REST APIs, prompt engineering, structured AI output, client-server architecture, data persistence, validation, and responsive UI design.
