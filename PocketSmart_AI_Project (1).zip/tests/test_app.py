import tempfile
from pathlib import Path
from app import create_app
from app.config import Config
from app.services.allocator import allocate_home,allocate_party

def test_home_allocation_balances_to_budget():
    p=allocate_home(80000,[{'name':'Sofa','quantity':1},{'name':'Lamp','quantity':2}]);assert p['allocated']==80000;assert p['remaining']==0

def test_party_allocation_balances_to_budget():
    p=allocate_party(60000,50,'Birthday','Community hall');assert p['allocated']==60000;assert p['remaining']==0;assert p['cost_per_guest']==1200

def test_api_validation():
    with tempfile.TemporaryDirectory() as d:
        class TestConfig(Config):TESTING=True;DATA_FILE=Path(d)/'budgets.json';GEMINI_API_KEY=''
        c=create_app(TestConfig).test_client();r=c.post('/api/home-plan',json={'budget':0,'items':[]});assert r.status_code==400

def test_save_and_list():
    with tempfile.TemporaryDirectory() as d:
        class TestConfig(Config):TESTING=True;DATA_FILE=Path(d)/'budgets.json';GEMINI_API_KEY=''
        c=create_app(TestConfig).test_client();created=c.post('/api/budgets',json={'type':'home','budget':50000}).get_json();assert created['id'];assert len(c.get('/api/budgets').get_json())==1
