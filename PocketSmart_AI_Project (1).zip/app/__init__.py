from flask import Flask
from .config import Config
from .routes import api


def create_app(config_class=Config):
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(config_class)
    app.register_blueprint(api)
    return app
