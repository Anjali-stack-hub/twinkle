HOME_WEIGHTS={
' sofa':3.0,'sofa':3.0,'bed':3.0,'wardrobe':2.4,'dining':2.5,'table':2.0,'chair':1.3,'desk':2.0,'tv':2.0,'cabinet':1.8,'storage':1.7,'shelf':1.5,'mattress':2.5,'curtain':1.0,'rug':1.0,'lamp':0.8,'lighting':0.8,'mirror':0.7,'decor':0.6,'fan':1.0,'refrigerator':3.5,'fridge':3.5,'washing':3.0,'oven':2.5,'stove':2.2,'microwave':1.8,'chimney':1.8,'appliance':2.0}
PARTY_PERCENTAGES={'birthday':{'food/catering':.42,'venue':.18,'decoration':.14,'entertainment':.10,'other':.16},'wedding':{'food/catering':.45,'venue':.22,'decoration':.15,'entertainment':.08,'other':.10},'engagement':{'food/catering':.40,'venue':.22,'decoration':.16,'entertainment':.08,'other':.14},'corporate':{'food/catering':.35,'venue':.25,'decoration':.08,'entertainment':.12,'other':.20},'other':{'food/catering':.40,'venue':.20,'decoration':.15,'entertainment':.10,'other':.15}}
def _weight(name):
    t=name.lower()
    for k,w in HOME_WEIGHTS.items():
        if k.strip() in t:return w
    return 1.0
def _money(v):return round(float(v),2)
def allocate_home(budget,items):
    if budget<=0:raise ValueError('Budget must be greater than zero.')
    if not items:raise ValueError('At least one item is required.')
    out=[]; total=0
    for item in items:
        name=str(item.get('name','')).strip(); qty=int(item.get('quantity',0))
        if not name:raise ValueError('Every item needs a name.')
        if qty<1 or qty>100:raise ValueError(f"Quantity for '{name}' must be between 1 and 100.")
        w=_weight(name)*qty; total+=w; out.append({'name':name,'quantity':qty,'weight':w})
    for i in out:i['allocated']=_money(budget*i['weight']/total)
    out[-1]['allocated']=_money(out[-1]['allocated']+(budget-sum(i['allocated'] for i in out)))
    return {'type':'home','budget':_money(budget),'allocated':_money(sum(i['allocated'] for i in out)),'remaining':_money(budget-sum(i['allocated'] for i in out)),'items':out,'over_budget':False}
def allocate_party(budget,guests,event_type,venue):
    if budget<=0:raise ValueError('Budget must be greater than zero.')
    if guests<1 or guests>10000:raise ValueError('Guests must be between 1 and 10,000.')
    if not event_type.strip():raise ValueError('Event type is required.')
    p=PARTY_PERCENTAGES.get(event_type.strip().lower(),PARTY_PERCENTAGES['other']).copy()
    if any(x in venue.lower() for x in ('home','house','free venue')):
        saved=p['venue'];p['venue']=.05;p['other']+=saved-.05
    b=[{'category':k,'percentage':round(v*100,1),'allocated':_money(budget*v)} for k,v in p.items()]
    b[-1]['allocated']=_money(b[-1]['allocated']+(budget-sum(x['allocated'] for x in b)))
    return {'type':'party','event_type':event_type.strip(),'guests':guests,'venue':venue.strip(),'budget':_money(budget),'allocated':_money(sum(x['allocated'] for x in b)),'remaining':_money(budget-sum(x['allocated'] for x in b)),'breakdown':b,'cost_per_guest':_money(budget/guests),'over_budget':False}
