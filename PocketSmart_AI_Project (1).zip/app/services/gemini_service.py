import json
from urllib.parse import quote_plus
try:
    from google import genai
    from google.genai import types
except ImportError:
    genai=None; types=None
DEMO_CATALOG={'sofa':('3-Seater Fabric Sofa',24000,'Comfortable modern seating with a budget-conscious price point.'),'bed':('Queen Storage Bed',28000,'Adds sleeping comfort plus useful under-bed storage.'),'wardrobe':('2-Door Engineered Wood Wardrobe',16000,'Balances storage capacity and cost for a bedroom.'),'table':('Compact Wooden Coffee Table',6500,'Works well in a modern room without consuming too much budget.'),'chair':('Ergonomic Accent Chair',7500,'Adds an extra seat while keeping the spend moderate.'),'lamp':('Warm LED Floor Lamp',2800,'Adds warm ambient lighting and suits a contemporary style.'),'tv':('43-inch 4K Smart TV',26000,'A practical mid-range entertainment option for a living room.'),'fridge':('Double-Door Frost-Free Refrigerator',32000,'A practical capacity-to-price option for a family kitchen.'),'microwave':('Convection Microwave Oven',12000,'Useful multi-purpose kitchen appliance at a moderate price.')}
def _source_url(name):return 'https://www.google.com/search?q='+quote_plus(name+' India price')
def _demo_recommendations(plan,prefs):
    rows=[]
    if plan.get('type')=='home':
        for item in plan.get('items',[]):
            match=next((v for k,v in DEMO_CATALOG.items() if k in item['name'].lower()),None)
            if match: product,price,reason=match
            else: product=f"Value-focused {item['name']} option"; price=round(item['allocated']/max(item['quantity'],1)); reason='A placeholder recommendation sized to the item’s allocated budget.'
            rows.append({'item':item['name'],'product_name':product,'estimated_price':price,'quantity':item['quantity'],'reason':reason+(f' Preference match: {prefs}.' if prefs else ''),'style_match':'Good','budget_fit':'Within allocated target','source_url':_source_url(product)})
        summary='Demo recommendations prioritize the highest-budget items first and preserve room for the remaining requirements.'
    else:
        def amt(cat):return next(x['allocated'] for x in plan['breakdown'] if x['category']==cat)
        rows=[{'item':'Food/catering','product_name':'Local buffet caterer shortlist','estimated_price':amt('food/catering'),'quantity':plan['guests'],'reason':f"Sized for about {plan['guests']} guests.",'style_match':'Good','budget_fit':'Within allocation','source_url':_source_url('buffet caterer India')},{'item':'Decoration','product_name':'Simple elegant event decoration package','estimated_price':amt('decoration'),'quantity':1,'reason':'Keeps decoration polished without dominating the event budget.','style_match':'Good','budget_fit':'Within allocation','source_url':_source_url('event decoration package India')},{'item':'Entertainment','product_name':'Compact DJ / speaker package','estimated_price':amt('entertainment'),'quantity':1,'reason':'A scalable option for a small-to-medium event.','style_match':'Good','budget_fit':'Within allocation','source_url':_source_url('DJ speaker package India')}]
        summary='Demo party suggestions are aligned with guest count, event type and the calculated spending buckets.'
    return {'summary':summary,'recommendations':rows,'tips':['Verify live prices, delivery charges, taxes and availability before purchase.','Keep a small contingency reserve for unexpected expenses.']}
def generate_recommendations(config,plan,preferences=''):
    if not config.GEMINI_API_KEY or genai is None:
        r=_demo_recommendations(plan,preferences);r['mode']='demo';return r
    client=genai.Client(api_key=config.GEMINI_API_KEY)
    schema={'type':'object','properties':{'summary':{'type':'string'},'recommendations':{'type':'array','items':{'type':'object','properties':{'item':{'type':'string'},'product_name':{'type':'string'},'estimated_price':{'type':'number'},'quantity':{'type':'integer'},'reason':{'type':'string'},'style_match':{'type':'string'},'budget_fit':{'type':'string'},'source_url':{'type':'string'}},'required':['item','product_name','estimated_price','quantity','reason','style_match','budget_fit','source_url']}},'tips':{'type':'array','items':{'type':'string'}}},'required':['summary','recommendations','tips']}
    prompt=f"""You are PocketSmart AI, a practical personal budgeting and recommendation assistant. Use only the user's plan. Do not claim stock availability. Prices are estimates, not guarantees. Recommend realistic products/services that fit each allocated amount and personalize to category, quantity, budget, style and preferences. For source_url, use a useful public source/search URL; if a direct seller URL is uncertain, use a Google search URL for the exact recommendation and append India price. Do not recommend spending above an allocated amount unless clearly labeled. Return concise explanations.\n\nPLAN:\n{json.dumps(plan,indent=2)}\n\nPREFERENCES:\n{preferences or 'No additional preferences provided.'}"""
    try:
        response=client.models.generate_content(model=config.GEMINI_MODEL,contents=prompt,config=types.GenerateContentConfig(response_mime_type='application/json',response_schema=schema,temperature=.4,max_output_tokens=3000))
        data=json.loads(response.text);data['mode']='gemini';return data
    except Exception as exc:
        r=_demo_recommendations(plan,preferences);r['mode']='fallback';r['warning']=f'Gemini was unavailable, so demo recommendations were shown: {str(exc)[:180]}';return r
