import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

def _ensure_file(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists(): path.write_text('[]', encoding='utf-8')

def read_all(path: Path):
    _ensure_file(path)
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
        return data if isinstance(data,list) else []
    except (json.JSONDecodeError,OSError): return []

def save_plan(path: Path, plan: dict):
    plans=read_all(path); record=dict(plan); record['id']=str(uuid4()); record['created_at']=datetime.now(timezone.utc).isoformat()
    plans.insert(0,record); path.write_text(json.dumps(plans,indent=2),encoding='utf-8'); return record

def delete_plan(path: Path, plan_id: str):
    plans=read_all(path); remaining=[p for p in plans if p.get('id')!=plan_id]
    if len(remaining)==len(plans): return False
    path.write_text(json.dumps(remaining,indent=2),encoding='utf-8'); return True
