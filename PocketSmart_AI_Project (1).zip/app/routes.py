from flask import Blueprint,current_app,jsonify,render_template,request
from .services.allocator import allocate_home,allocate_party
from .services.gemini_service import generate_recommendations
from .services.storage import delete_plan,read_all,save_plan
api=Blueprint('api',__name__)
def _json():
    data=request.get_json(silent=True)
    if not isinstance(data,dict):raise ValueError('Request body must be a JSON object.')
    return data
@api.get('/')
def home():return render_template('index.html')
@api.get('/api/health')
def health():return jsonify({'ok':True,'gemini_configured':bool(current_app.config['GEMINI_API_KEY']),'model':current_app.config['GEMINI_MODEL']})
@api.post('/api/home-plan')
def home_plan():
    try:
        d=_json();p=allocate_home(float(d.get('budget',0)),d.get('items',[]));p['room_type']=str(d.get('room_type','Living Room'));p['preferences']=str(d.get('preferences','')).strip();return jsonify(p)
    except (ValueError,TypeError) as e:return jsonify({'error':str(e)}),400
@api.post('/api/party-plan')
def party_plan():
    try:
        d=_json();p=allocate_party(float(d.get('budget',0)),int(d.get('guests',0)),str(d.get('event_type','')),str(d.get('venue','')));p['preferences']=str(d.get('preferences','')).strip();return jsonify(p)
    except (ValueError,TypeError) as e:return jsonify({'error':str(e)}),400
@api.post('/api/recommendations')
def recommendations():
    try:
        d=_json();plan=d.get('plan')
        if not isinstance(plan,dict):raise ValueError('A valid plan object is required.')
        return jsonify(generate_recommendations(current_app.config,plan,str(d.get('preferences',plan.get('preferences','')))))
    except ValueError as e:return jsonify({'error':str(e)}),400
    except Exception as e:return jsonify({'error':f'Recommendation service error: {str(e)}'}),500
@api.get('/api/budgets')
def budgets():return jsonify(read_all(current_app.config['DATA_FILE']))
@api.post('/api/budgets')
def create_budget():
    try:
        d=_json()
        if 'type' not in d or 'budget' not in d:raise ValueError('Saved plan needs type and budget.')
        return jsonify(save_plan(current_app.config['DATA_FILE'],d)),201
    except ValueError as e:return jsonify({'error':str(e)}),400
@api.delete('/api/budgets/<plan_id>')
def remove_budget(plan_id):
    return (jsonify({'ok':True}),200) if delete_plan(current_app.config['DATA_FILE'],plan_id) else (jsonify({'error':'Plan not found.'}),404)
@api.errorhandler(404)
def not_found(error):
    return jsonify({'error':'API endpoint not found.'}),404 if request.path.startswith('/api/') else error
