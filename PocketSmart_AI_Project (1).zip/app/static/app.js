const state = { currentPlan: null, recommendations: null };
const $ = (id) => document.getElementById(id);
const money = (n) => `₹${Number(n || 0).toLocaleString('en-IN', {maximumFractionDigits: 0})}`;

function toast(message) { const el=$('toast'); el.textContent=message; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2600); }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

function addHomeItem(name='', quantity=1) {
  const row=document.createElement('div'); row.className='item-row';
  row.innerHTML=`<input class="item-name" placeholder="e.g. Sofa" value="${escapeHtml(name)}" required><input class="item-qty" type="number" min="1" max="100" value="${quantity}" required><button type="button" class="remove-btn" aria-label="Remove item">×</button>`;
  row.querySelector('.remove-btn').onclick=()=>row.remove(); $('homeItems').appendChild(row);
}

function setTab(tab) { document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active', b.dataset.tab===tab)); document.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active', p.id===tab)); if(tab==='summary') renderSummary(); }
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
$('addHomeItem').onclick=()=>addHomeItem();
addHomeItem('Sofa',1); addHomeItem('Coffee table',1); addHomeItem('Floor lamp',2);

async function api(url, options={}) { const r=await fetch(url,{headers:{'Content-Type':'application/json'},...options}); const data=await r.json().catch(()=>({})); if(!r.ok) throw new Error(data.error||'Request failed'); return data; }

function renderHomePreview(plan) {
  $('homePreview').classList.remove('empty-state');
  $('homePreview').innerHTML=`<div class="card-title"><div><span class="section-number">PLAN</span><h2>${escapeHtml(plan.room_type)}</h2></div><span class="tag">${money(plan.budget)}</span></div><div class="allocation-list">${plan.items.map(i=>{const pct=i.allocated/plan.budget*100; return `<div class="allocation-row"><div><strong>${escapeHtml(i.name)}</strong><small> × ${i.quantity}</small></div><div class="money">${money(i.allocated)}</div><div class="bar"><span style="width:${Math.min(100,pct)}%"></span></div></div>`}).join('')}</div><hr style="border:0;border-top:1px solid var(--line);margin:20px 0"><div style="display:flex;justify-content:space-between"><strong>Remaining</strong><strong class="positive">${money(plan.remaining)}</strong></div>`;
}
function renderPartyPreview(plan) {
  $('partyPreview').classList.remove('empty-state');
  $('partyPreview').innerHTML=`<div class="card-title"><div><span class="section-number">PLAN</span><h2>${escapeHtml(plan.event_type)}</h2></div><span class="tag">${plan.guests} guests</span></div><div class="allocation-list">${plan.breakdown.map(i=>`<div class="allocation-row"><div><strong>${escapeHtml(i.category)}</strong><small> ${i.percentage}%</small></div><div class="money">${money(i.allocated)}</div><div class="bar"><span style="width:${i.percentage}%"></span></div></div>`).join('')}</div><hr style="border:0;border-top:1px solid var(--line);margin:20px 0"><div style="display:flex;justify-content:space-between"><span>Per guest</span><strong>${money(plan.cost_per_guest)}</strong></div><div style="display:flex;justify-content:space-between;margin-top:8px"><strong>Remaining</strong><strong class="positive">${money(plan.remaining)}</strong></div>`;
}

$('homeForm').onsubmit=async(e)=>{e.preventDefault(); try{const items=[...document.querySelectorAll('.item-row')].map(r=>({name:r.querySelector('.item-name').value,quantity:Number(r.querySelector('.item-qty').value)})); const plan=await api('/api/home-plan',{method:'POST',body:JSON.stringify({room_type:$('roomType').value,budget:Number($('homeBudget').value),preferences:$('homePreferences').value,items})}); state.currentPlan=plan; state.recommendations=null; renderHomePreview(plan); updateHero(); toast('Home budget calculated.');}catch(err){toast(err.message)}};
$('partyForm').onsubmit=async(e)=>{e.preventDefault(); try{const plan=await api('/api/party-plan',{method:'POST',body:JSON.stringify({event_type:$('eventType').value,guests:Number($('guests').value),budget:Number($('partyBudget').value),venue:$('venue').value,preferences:$('partyPreferences').value})}); state.currentPlan=plan; state.recommendations=null; renderPartyPreview(plan); updateHero(); toast('Party budget calculated.');}catch(err){toast(err.message)}};

function updateHero(){ $('heroRemaining').textContent=money(state.currentPlan?.remaining); renderSummary(); }
function renderSummary(){const p=state.currentPlan; $('summaryCards').innerHTML=p?`<div class="card summary-stat"><small>Total budget</small><strong>${money(p.budget)}</strong></div><div class="card summary-stat"><small>Allocated</small><strong>${money(p.allocated)}</strong></div><div class="card summary-stat"><small>Remaining</small><strong class="${p.remaining<0?'negative':'positive'}">${money(p.remaining)}</strong></div>`:`<div class="card summary-stat"><small>Total budget</small><strong>₹0</strong></div><div class="card summary-stat"><small>Allocated</small><strong>₹0</strong></div><div class="card summary-stat"><small>Remaining</small><strong>₹0</strong></div>`; $('warningBox').innerHTML=p&&p.remaining<0?`<div class="warning"><strong>Budget exceeded.</strong> Your planned allocation is ${money(Math.abs(p.remaining))} above the available budget. Reduce quantities or increase the budget before purchasing.</div>`:''; loadSaved(); }

$('getRecommendations').onclick=async()=>{if(!state.currentPlan){toast('Create a budget plan first.'); return} const banner=$('recommendationBanner'); banner.textContent='Gemini is preparing personalized recommendations…'; try{const data=await api('/api/recommendations',{method:'POST',body:JSON.stringify({plan:state.currentPlan,preferences:state.currentPlan.preferences||''})}); state.recommendations=data; banner.textContent=`${data.mode==='gemini'?'Gemini':'Demo'} recommendations • ${data.summary}`; if(data.warning) banner.textContent += ` ${data.warning}`; $('recommendationGrid').innerHTML=data.recommendations.map(r=>`<article class="card recommendation-card"><div class="rec-meta"><span>${escapeHtml(r.item)}</span><span>${escapeHtml(r.budget_fit)}</span><span>${escapeHtml(r.style_match)} style match</span></div><h3>${escapeHtml(r.product_name)}</h3><p class="money">Estimated: ${money(r.estimated_price)}${r.quantity>1?` × ${r.quantity}`:''}</p><p>${escapeHtml(r.reason)}</p><a class="source-link" href="${escapeHtml(r.source_url)}" target="_blank" rel="noopener">View source / search →</a></article>`).join(''); if(data.tips?.length) $('recommendationGrid').insertAdjacentHTML('beforeend',`<article class="card recommendation-card"><h3>Smart tips</h3><p>${data.tips.map(escapeHtml).join('<br>')}</p></article>`); setTab('recommendations');}catch(err){banner.textContent=err.message}};

$('savePlan').onclick=async()=>{if(!state.currentPlan){toast('Create a plan first.');return} try{await api('/api/budgets',{method:'POST',body:JSON.stringify({...state.currentPlan,recommendations:state.recommendations})});toast('Plan saved.');loadSaved();}catch(err){toast(err.message)}};
async function loadSaved(){try{const plans=await api('/api/budgets');$('savedPlans').innerHTML=plans.length?plans.map(p=>`<div class="saved-row"><div><strong>${escapeHtml(p.room_type||p.event_type||'Budget plan')}</strong><small> • ${escapeHtml(p.type)} • ${money(p.budget)}</small></div><button class="delete-btn" onclick="deletePlan('${p.id}')">Delete</button></div>`).join(''):'<p style="color:var(--muted)">No saved plans yet.</p>'}catch(err){console.error(err)}}
window.deletePlan=async(id)=>{try{await api('/api/budgets/'+id,{method:'DELETE'});toast('Saved plan deleted.');loadSaved()}catch(err){toast(err.message)}};

(async()=>{try{const h=await api('/api/health');$('aiStatus').textContent=h.gemini_configured?`Gemini • ${h.model}`:'Demo mode • Add Gemini key';}catch{ $('aiStatus').textContent='Offline demo'; } renderSummary();})();
