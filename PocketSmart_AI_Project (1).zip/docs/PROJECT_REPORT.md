# PocketSmart AI — College Project Report

## 1. Title
**PocketSmart AI: Your Smart Budget & Recommendation Assistant**

## 2. Problem statement
People often know their total spending limit but do not know how to divide it across multiple requirements. Generic shopping suggestions also fail to account for quantity, style, priorities, and the user's actual budget. PocketSmart AI addresses both problems through rule-based budget allocation plus Generative AI recommendations.

## 3. Objective
Build a lightweight web application that collects home and party planning requirements, calculates an item/category budget allocation, tracks remaining money, warns about overspending, uses Gemini to produce personalized recommendations, and stores plans in a simple JSON database.

## 4. Technology stack
- Frontend: HTML5, CSS3, vanilla JavaScript
- Backend: Python Flask
- Generative AI: Google Gemini API via the Google GenAI Python SDK
- Storage: JSON file
- API format: REST + JSON

## 5. AI workflow
1. User enters budget, requirements, quantities, and preferences.
2. Flask validates the input.
3. The allocation engine calculates target spending per item/category.
4. The structured plan is sent to Gemini with a JSON schema.
5. Gemini returns recommendations containing product/service name, estimated price, explanation, style match, budget fit, and a source/search URL.
6. The frontend renders recommendation cards.
7. If Gemini is unavailable, the application falls back to a deterministic demo catalog.

## 6. Prompt engineering
The prompt instructs Gemini to use only supplied requirements, avoid claiming inventory, treat prices as estimates, fit recommendations to allocated budgets, personalize to preferences, and return structured JSON. This makes output easier to validate and render.

## 7. Budget algorithm
Home plans assign weights based on item type and quantity. Each item receives:

`item allocation = total budget × (item weight × quantity) / sum of all item weights`

Party plans use event-specific percentages for food, venue, decoration, entertainment, and other costs. If the venue is the user's home, the venue percentage is reduced and moved to the other bucket.

## 8. Database design
The JSON file contains an array of saved plan objects. Each record includes a UUID, timestamp, plan type, budget, allocation, details, preferences, and optional recommendations. For production, replace JSON storage with SQLite/PostgreSQL and add authentication.

## 9. Error handling
- Invalid/missing JSON returns HTTP 400.
- Invalid budgets and quantities are rejected.
- Gemini failures trigger a safe fallback recommendation response.
- Unknown API routes return API errors.
- API keys are loaded from environment variables and never placed in frontend code.

## 10. Future scope
Live retailer/catalog APIs for verified prices; user accounts; cloud database; price alerts; budget history charts; multilingual recommendations; receipt upload; expense categorization; and Google Search grounding or retailer integrations.

## 11. Viva talking points
- **Why Generative AI?** It interprets natural-language preferences and produces personalized explanations.
- **Why rule-based allocation too?** Deterministic arithmetic keeps budgeting predictable while AI handles personalization.
- **How is output controlled?** Gemini receives a structured JSON schema.
- **What happens without API access?** Demo mode keeps the main workflow usable.
- **How can it become production-ready?** Add authentication, verified product data, a real database, and retailer integrations.
